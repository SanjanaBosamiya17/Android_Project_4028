package com.example.verifylogin;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class DashboardActivity extends AppCompatActivity {

    TextView tvUsername, tvPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        tvUsername = findViewById(R.id.tvUsername);
        tvPassword = findViewById(R.id.tvPassword);

        // Get username and password passed from MainActivity
        String username = getIntent().getStringExtra("username");
        String password = getIntent().getStringExtra("password");

        tvUsername.setText(username);
        tvPassword.setText(password);
    }
}