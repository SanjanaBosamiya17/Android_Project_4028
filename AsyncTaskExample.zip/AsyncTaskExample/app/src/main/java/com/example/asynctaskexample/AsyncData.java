package com.example.asynctaskexample;

import android.app.AlertDialog;
import android.content.Context;
import android.os.AsyncTask;

public class AsyncData extends AsyncTask<String,Integer,String> {

    // Constructor for Context
    Context localContext;

    // Alert Dialog from dialogs
    AlertDialog.Builder builder;
    public AsyncData(MainActivity globalContext) {
        localContext = globalContext;
    }

    // PreExecute starts without any requirements so for declaration can be used.
    @Override
    protected void onPreExecute() {
        builder = new AlertDialog.Builder(localContext);
    }

    // For AsyncTask
    @Override
    protected String doInBackground(String... strings) {
        // Using Parameters as strings
        String data = strings[0];
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        // This return methods will pass dfata to onPostExecute( as a string only)
        return data;
    }

    @Override
    protected void onPostExecute(String data) {
        // Then we are printing data in Dialog.
        // You can also use Toast for simple structure.
        builder.setMessage(data)
                .setTitle("AsyncTaskExample")
                .setCancelable(true)
                .setIcon(R.drawable.ic_launcher_background)
                .show();
    }

}
