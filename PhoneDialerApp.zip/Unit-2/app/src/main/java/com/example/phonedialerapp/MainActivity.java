package com.example.phonedialerapp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    // Permission request code
    private static final int CALL_PERMISSION_CODE = 101;

    // Declare UI variables
    EditText etPhoneNumber;
    Button btnCall;
    Button btnClear;
    TextView tvError;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Connect UI elements to Java variables
        etPhoneNumber = findViewById(R.id.etPhoneNumber);
        btnCall       = findViewById(R.id.btnCall);
        btnClear      = findViewById(R.id.btnClear);
        tvError       = findViewById(R.id.tvError);

        // CALL button click
        btnCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String number = etPhoneNumber.getText().toString().trim();

                // Validation — check if field is empty
                if (number.isEmpty()) {
                    tvError.setText("⚠️ Please enter a phone number");
                    return;
                }

                // Validation — check minimum digits
                if (number.length() < 7) {
                    tvError.setText("⚠️ Number seems too short");
                    return;
                }

                // Clear any previous error
                tvError.setText("");

                // Check if CALL_PHONE permission is granted
                if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CALL_PHONE)
                        == PackageManager.PERMISSION_GRANTED) {
                    // Permission already granted — make the call
                    makeCall(number);
                } else {
                    // Ask user for permission
                    ActivityCompat.requestPermissions(
                            MainActivity.this,
                            new String[]{Manifest.permission.CALL_PHONE},
                            CALL_PERMISSION_CODE
                    );
                }
            }
        });

        // CLEAR button click
        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etPhoneNumber.getText().clear();
                tvError.setText("");
            }
        });
    }

    // This function actually initiates the call
    private void makeCall(String number) {
        Intent callIntent = new Intent(Intent.ACTION_CALL);
        callIntent.setData(Uri.parse("tel:" + number));
        startActivity(callIntent);
    }

    // This is called after the user responds to the permission popup
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == CALL_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // User allowed — now make the call
                String number = etPhoneNumber.getText().toString().trim();
                makeCall(number);
            } else {
                // User denied — show message
                tvError.setText("⚠️ Call permission denied. Please allow it in settings.");
            }
        }
    }
}