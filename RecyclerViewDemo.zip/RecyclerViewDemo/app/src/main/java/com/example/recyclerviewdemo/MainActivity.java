package com.example.recyclerviewdemo;

import android.os.Bundle;
import android.widget.LinearLayout;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.recyclerview);

        List<Item> items = new ArrayList<Item>();
        items.add(new Item("John wick", "john.wick@email.com",R.drawable.profile1));
        items.add(new Item("Robert j", "robert.j@email.com",R.drawable.profile1));
        items.add(new Item("James Gun", "james.gun@email.com",R.drawable.profile1));
        items.add(new Item("Ricky tales", "ricky.talesk@email.com",R.drawable.profile1));
        items.add(new Item("Micky mouse", "mickey.mouse@email.com",R.drawable.profile1));
        items.add(new Item("Pick war", "pick.war@email.com",R.drawable.profile1));
        items.add(new Item("Apple mac", "apple.mac@email.com",R.drawable.profile1));

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new MyAdapter(getApplicationContext(),items));

    }
}